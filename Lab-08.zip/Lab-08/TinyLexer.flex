%%

%class TinyLexer
%standalone
%unicode

/* ── Definitions ─────────────────────────────── */
DIGIT      = [0-9]
LETTER     = [a-zA-Z]
NUMBER     = {DIGIT}+
IDENTIFIER = {LETTER}+
WHITESPACE = [ \t\r\n]+

/* Reserved words */
IF     = "if"
THEN   = "then"
ELSE   = "else"
END    = "end"
REPEAT = "repeat"
UNTIL  = "until"
READ   = "read"
WRITE  = "write"

%%

/* ── Rules ───────────────────────────────────── */

/* Skip whitespace silently */
{WHITESPACE}    { /* ignore */ }

/* Remove (skip) comments */
"{" [^}]* "}"   { /* skip comments */ }

/* Reserved words – must come BEFORE identifier rule */
{IF}            { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{THEN}          { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{ELSE}          { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{END}           { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{REPEAT}        { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{UNTIL}         { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{READ}          { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }
{WRITE}         { System.out.println(yytext() + " <Reserved Word, " + yytext() + ">"); }

/* Identifiers (any word that is NOT a reserved word) */
{IDENTIFIER}    { System.out.println(yytext() + " <identifier, " + yytext() + ">"); }

/* Integer constants */
{NUMBER}        { System.out.println(yytext() + " <Number, " + yytext() + ">"); }

/* Assignment operator – must come BEFORE '=' rule */
":="            { System.out.println(yytext() + " <Assignment, :=>"); }

/* Operators */
"+"             { System.out.println(yytext() + " <Plus, +>"); }
"-"             { System.out.println(yytext() + " <Minus, ->"); }
"*"             { System.out.println(yytext() + " <Multiplication, *>"); }
"/"             { System.out.println(yytext() + " <Division, />"); }
"="             { System.out.println(yytext() + " <Equals, =>"); }
"<"             { System.out.println(yytext() + " <Less Than, <>"); }
"("             { System.out.println(yytext() + " <Open Paren, (>"); }
")"             { System.out.println(yytext() + " <Close Paren, )>"); }
";"             { System.out.println(yytext() + " <Statement Terminator, ;>"); }

/* Unrecognized characters */
.               { System.out.println(yytext() + " <Unrecognized token, " + yytext() + ">"); }
