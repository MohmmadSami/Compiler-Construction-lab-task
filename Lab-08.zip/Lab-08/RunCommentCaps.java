import java.io.*;

public class RunCommentCaps {
    public static void main(String[] args) throws Exception {
        CommentCaps lexer = new CommentCaps(new InputStreamReader(System.in));
        lexer.yylex();
    }
}
