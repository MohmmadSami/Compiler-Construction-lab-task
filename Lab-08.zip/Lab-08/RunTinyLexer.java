import java.io.*;

public class RunTinyLexer {
    public static void main(String[] args) throws Exception {
        TinyLexer lexer = new TinyLexer(new InputStreamReader(System.in));
        lexer.yylex();
    }
}
