%%

%class CommentCaps
%standalone
%unicode

%%

"{" [^}]* "}"    {
                    String comment = yytext();
                    System.out.print(comment.toUpperCase());
                 }

[^{]             { System.out.print(yytext()); }
