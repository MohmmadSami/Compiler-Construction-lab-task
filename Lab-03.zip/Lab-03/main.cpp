#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
using namespace std;

ifstream in("input.tiny");
ofstream out("output.tiny");
char ch;

string keywords[] = {"read","write","if","then",
                     "else","end","repeat","until"};

bool isKeyword(string s){
    for(int i=0;i<8;i++)
        if(s==keywords[i]) return true;
    return false;
}

void getChar(){ in.get(ch); }

void skipWhite(){
    while(isspace(ch) && !in.eof())
        getChar();
}

void skipComment(){
    if(ch=='{'){
        while(ch!='}' && !in.eof())
            getChar();
        getChar();
    }
}

void getToken(){

    skipWhite();
    skipComment();
    skipWhite();

    string lex="";

    if(isalpha(ch)){                    // Identifier / Keyword
        while(isalpha(ch)){
            lex+=ch; getChar();
        }
        if(isKeyword(lex))
            out<<"KEYWORD: "<<lex<<endl;
        else
            out<<"IDENTIFIER: "<<lex<<endl;
    }

    else if(isdigit(ch)){               // Number
        while(isdigit(ch)){
            lex+=ch; getChar();
        }
        out<<"NUMBER: "<<lex<<endl;
    }

    else{                               // Symbols
        switch(ch){
            case '+': out<<"PLUS: +"<<endl; break;
            case '-': out<<"MINUS: -"<<endl; break;
            case '*': out<<"MULTIPLY: *"<<endl; break;
            case '/': out<<"DIVIDE: /"<<endl; break;
            case '<': out<<"LESS_THAN: <"<<endl; break;
            case '=': out<<"EQUAL: ="<<endl; break;
            case ';': out<<"SEMICOLON: ;"<<endl; break;
            case '(': out<<"LPAREN: ("<<endl; break;
            case ')': out<<"RPAREN: )"<<endl; break;

            case ':':
                getChar();
                if(ch=='=') out<<"ASSIGN: :="<<endl;
                else out<<"INVALID TOKEN"<<endl;
                break;

            default:
                if(!in.eof())
                    out<<"UNKNOWN: "<<ch<<endl;
        }
        getChar();
    }
}

int main(){
    if(!in){ cout<<"File not found!\n"; return 1; }
    getChar();
    while(!in.eof())
        getToken();
    cout<<"Lexical Analysis Completed.\n";
    return 0;
}