#include <iostream>
#include <cstring>
using namespace std;

/*
  DFA using switch statement
  Language: a(bb)*bc
*/
int isAccepted_SWITCH(char str[]) {
    int state = 0; // Q0

    for (int i = 0; str[i] != '\0'; i++) {
        switch (state) {

        case 0: // Expect 'a'
            if (str[i] == 'a') state = 1;
            else return 0;
            break;

        case 1: // Expect 'b'
            if (str[i] == 'b') state = 2;
            else return 0;
            break;

        case 2: // First 'b' or 'c'
            if (str[i] == 'b') state = 3;
            else if (str[i] == 'c') state = 5;
            else return 0;
            break;

        case 3: // Repeating (bb)*
            if (str[i] == 'b') state = 2;
            else if (str[i] == 'c') state = 5;
            else return 0;
            break;

        case 5: // Should not read more input
            return 0;
        }
    }

    return (state == 5);
}

int main() {
    char str[100];

    cout << "Enter a string: ";
    cin >> str;

    if (isAccepted_SWITCH(str))
        cout << "ACCEPTED";
    else
        cout << "NOT ACCEPTED";

    return 0;
}
