#include <iostream>
#include <cstring>
using namespace std;

/*
  Validate alphabet Σ = {a, b, c}
*/
int isValidAlphabet(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] != 'a' && str[i] != 'b' && str[i] != 'c')
            return 0;
    }
    return 1;
}

/*
  DFA using goto statements
  Language: a(bb)*bc
*/
int isAccepted_GOTO(char str[]) {
    int i = 0;
    goto Q0;

    Q0: // Start state, expecting 'a'
        if (str[i] == 'a') { i++; goto Q1; }
    return 0;

    Q1: // After 'a', expecting 'b'
        if (str[i] == 'b') { i++; goto Q2; }
    return 0;

    Q2: // First 'b' of (bb)* OR final 'b'
        if (str[i] == 'b') { i++; goto Q3; }
    if (str[i] == 'c') goto Q5;
    return 0;

    Q3: // Completed one 'bb' pair
        if (str[i] == 'b') { i++; goto Q2; }
    if (str[i] == 'c') goto Q5;
    return 0;

    Q5: // Accepting state
        if (str[i] == 'c' && str[i + 1] == '\0')
            return 1;
    return 0;
}

int main() {
    char str[100];

    cout << "Enter a string: ";
    cin >> str;

    if (!isValidAlphabet(str)) {
        cout << "Invalid Alphabet!";
        return 0;
    }

    if (isAccepted_GOTO(str))
        cout << "ACCEPTED";
    else
        cout << "NOT ACCEPTED";

    return 0;
}
