#include <iostream>
#include <cstring>
using namespace std;

/*
  DFA using switch statement
  Even number of a's and b's
*/
int isAccepted_SWITCH(char str[]) {
    int state = 0; // Q0: Even a, Even b

    for (int i = 0; str[i] != '\0'; i++) {
        switch (state) {

        case 0:
            if (str[i] == 'a') state = 1;
            else if (str[i] == 'b') state = 2;
            break;

        case 1:
            if (str[i] == 'a') state = 0;
            else if (str[i] == 'b') state = 3;
            break;

        case 2:
            if (str[i] == 'a') state = 3;
            else if (str[i] == 'b') state = 0;
            break;

        case 3:
            if (str[i] == 'a') state = 2;
            else if (str[i] == 'b') state = 1;
            break;
        }
    }

    return (state == 0);
}

int main() {
    char str[100];

    cout << "Enter a string: ";
    cin >> str;

    if (isAccepted_SWITCH(str))
        cout << "ACCEPTED";
    else
        cout << "NOT ACCEPTED";

    return 0;
}
