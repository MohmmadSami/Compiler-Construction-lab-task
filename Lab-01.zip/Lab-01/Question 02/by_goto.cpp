#include <iostream>
#include <cstring>
using namespace std;

/*
  Validate alphabet Σ = {a, b}
*/
int isValidAlphabet(char str[]) {
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] != 'a' && str[i] != 'b')
            return 0;
    }
    return 1;
}

/*
  DFA using goto
  Accepts strings with even number of a's and b's
*/
int isAccepted_GOTO(char str[]) {
    int i = 0;
    goto Q0;

    Q0: // Even a, Even b (ACCEPTING)
        if (str[i] == 'a') { i++; goto Q1; }
    if (str[i] == 'b') { i++; goto Q2; }
    if (str[i] == '\0') return 1;
    return 0;

    Q1: // Odd a, Even b
        if (str[i] == 'a') { i++; goto Q0; }
    if (str[i] == 'b') { i++; goto Q3; }
    if (str[i] == '\0') return 0;
    return 0;

    Q2: // Even a, Odd b
        if (str[i] == 'a') { i++; goto Q3; }
    if (str[i] == 'b') { i++; goto Q0; }
    if (str[i] == '\0') return 0;
    return 0;

    Q3: // Odd a, Odd b
        if (str[i] == 'a') { i++; goto Q2; }
    if (str[i] == 'b') { i++; goto Q1; }
    if (str[i] == '\0') return 0;
    return 0;
}

int main() {
    char str[100];

    cout << "Enter a string: ";
    cin >> str;

    if (!isValidAlphabet(str)) {
        cout << "Invalid Alphabet!";
        return 0;
    }

    if (isAccepted_GOTO(str))
        cout << "ACCEPTED";
    else
        cout << "NOT ACCEPTED";

    return 0;
}
