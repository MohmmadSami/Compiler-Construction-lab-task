/* ============================================================
   EXPERIMENT 5 – PART 1, TASK 1
   TINY Language Lexical Analyzer
   CS4703 Compiler Construction | Mr. Tajamul Shahzad
   ============================================================ */

/* ── SECTION 1: User Code & Declarations ─────────────────── */
%%

%class TinyLexer
%public
%int
%standalone

/* ── SECTION 2: Regular Expression Definitions (Macros) ───── */

DIGIT       = [0-9]
LETTER      = [a-zA-Z]
INTEGER     = {DIGIT}+
IDENTIFIER  = {LETTER}({LETTER}|{DIGIT})*
WHITESPACE  = [ \t\r\n]+

/* ── SECTION 3: Lexical Rules ─────────────────────────────── */
%%

/* Skip whitespace silently */
{WHITESPACE}        { /* ignore */ }

/* Keywords  – must appear BEFORE the identifier rule */
"write"             { System.out.println("Keyword: write"); }

/* Integer constants */
{INTEGER}           { System.out.println("Integer: " + yytext()); }

/* Identifiers */
{IDENTIFIER}        { System.out.println("An identifier: " + yytext()); }

/* Recognised operator */
"*"                 { System.out.println("Operator: MULTIPLY"); }

/* Catch-all – anything that did not match above */
.                   { System.out.println("Unrecognized character: " + yytext()); }
