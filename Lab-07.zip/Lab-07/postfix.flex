/* ============================================================
   EXPERIMENT 5 – PART 1, TASK 2
   Postfix Expression Evaluator (JFlex-based Lexical Analyzer)
   CS4703 Compiler Construction | Mr. Tajamul Shahzad

   Supported operators : +  -  *
   Input example       : 44 33 22 * + 1 -
   Expected result     : 769
   ============================================================ */

/* ── SECTION 1: User Code & Declarations ─────────────────── */

import java.util.Stack;

%%

%class PostfixEvaluator
%public
%int
%standalone

/* Expose the operand stack and display helper to the rules section */
%{
    /* Stack holds integer operands during evaluation */
    private Stack<Integer> stack = new Stack<>();

    /**
     * Prints the current stack state in the required format:
     *   top-of-stack first, then remaining values, padded with 0s
     *   up to four columns.
     *
     * Example after pushing 33 onto [44]:
     *   33 44 0 0
     */
    private void printStack() {
        // Copy stack contents: index 0 = top-of-stack
        Integer[] arr = stack.toArray(new Integer[0]);
        int cols = 4;                          // always print 4 columns
        StringBuilder sb = new StringBuilder();

        for (int i = arr.length - 1; i >= 0; i--) {
            sb.append(arr[i]).append(" ");
        }
        // Pad remaining columns with 0
        for (int i = arr.length; i < cols; i++) {
            sb.append("0 ");
        }
        System.out.println(sb.toString().trim());
    }
%}

/* ── SECTION 2: Regular Expression Definitions (Macros) ───── */

DIGIT      = [0-9]
INTEGER    = {DIGIT}+
WHITESPACE = [ \t\r\n]+

/* ── SECTION 3: Lexical Rules ─────────────────────────────── */
%%

/* Skip whitespace silently */
{WHITESPACE}   { /* ignore */ }

/* ── Operand: push value and show stack ─────────────────── */
{INTEGER} {
    int value = Integer.parseInt(yytext());
    stack.push(value);
    printStack();
}

/* ── Operators: pop two, compute, push result, show stack ── */
"+" {
    int b = stack.pop();
    int a = stack.pop();
    stack.push(a + b);
    printStack();
}

"-" {
    int b = stack.pop();
    int a = stack.pop();
    stack.push(a - b);
    printStack();
}

"*" {
    int b = stack.pop();
    int a = stack.pop();
    stack.push(a * b);
    printStack();
}

/* ── End-of-file: print final result ────────────────────── */
<<EOF>> {
    if (!stack.isEmpty()) {
        System.out.println("result = " + stack.pop());
    }
    return YYEOF;
}

/* ── Catch-all: ignore unrecognised characters ──────────── */
.  { /* ignore */ }
