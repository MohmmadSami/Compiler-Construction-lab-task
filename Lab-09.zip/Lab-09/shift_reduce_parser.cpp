/*
 * ============================================================
 *  Riphah International University — Compiler Construction
 *  Lab 09: Shift Reduce Parser
 * ============================================================
 *  Grammar Rules:
 *      E → E + E
 *      E → E * E
 *      E → id
 *
 *  Input String: id + id * id
 * ============================================================
 */

#include <iostream>
#include <stack>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

// ─────────────────────────────────────────────
//  Helper: Convert the stack contents to a
//  single string for display purposes
// ─────────────────────────────────────────────
string stackToString(stack<string> stk) {
    // stack<> has no iterator, so collect into a vector first
    vector<string> items;
    while (!stk.empty()) {
        items.push_back(stk.top());
        stk.pop();
    }

    string result = "$";
    // items are in reverse order (bottom → top), so reverse back
    for (int i = items.size() - 1; i >= 0; i--) {
        result += items[i];
    }
    return result;
}

// ─────────────────────────────────────────────
//  Helper: Convert remaining input tokens to
//  a display string
// ─────────────────────────────────────────────
string inputToString(const vector<string>& tokens, int pos) {
    string result = "";
    for (int i = pos; i < (int)tokens.size(); i++) {
        result += tokens[i];
    }
    result += "$";
    return result;
}

// ─────────────────────────────────────────────
//  REDUCE function
//  Checks if the top of the stack matches any
//  grammar rule's RHS and reduces it to LHS.
//
//  Rules checked (bottom→top on stack):
//    1. E + E  →  E
//    2. E * E  →  E
//    3. id     →  E
//
//  Returns true if a reduction was made.
// ─────────────────────────────────────────────
bool tryReduce(stack<string>& stk, string& action) {

    // We need to inspect the top 3 elements for binary rules
    // First, collect top elements (up to 3)
    vector<string> top;
    stack<string> temp;

    for (int i = 0; i < 3 && !stk.empty(); i++) {
        top.push_back(stk.top());
        temp.push(stk.top());
        stk.pop();
    }

    // Restore the stack immediately (we'll modify if rule matches)
    while (!temp.empty()) {
        stk.push(temp.top());
        temp.pop();
    }

    // ── Rule: E + E → E ──────────────────────
    // top[0]=E, top[1]='+', top[2]=E   (remember: top[0] is topmost)
    if (top.size() >= 3 &&
        top[0] == "E" && top[1] == "+" && top[2] == "E") {

        // Pop 3 symbols off the stack
        stk.pop(); stk.pop(); stk.pop();
        // Push the LHS non-terminal
        stk.push("E");
        action = "REDUCE  E → E + E";
        return true;
    }

    // ── Rule: E * E → E ──────────────────────
    if (top.size() >= 3 &&
        top[0] == "E" && top[1] == "*" && top[2] == "E") {

        stk.pop(); stk.pop(); stk.pop();
        stk.push("E");
        action = "REDUCE  E → E * E";
        return true;
    }

    // ── Rule: id → E ─────────────────────────
    // Only the topmost element needs to be "id"
    if (!stk.empty() && stk.top() == "id") {
        stk.pop();
        stk.push("E");
        action = "REDUCE  E → id";
        return true;
    }

    return false;   // No rule matched
}

// ─────────────────────────────────────────────
//  Main parser function
// ─────────────────────────────────────────────
void shiftReduceParser(const vector<string>& tokens) {

    stack<string> stk;          // Parsing stack (bottom is '$')
    int pos = 0;                // Current position in token stream
    int step = 0;               // Step counter for the trace table

    // ── Print table header ────────────────────
    cout << "\n";
    cout << left
         << setw(6)  << "Step"
         << setw(25) << "Stack"
         << setw(25) << "Input"
         << setw(25) << "Action"
         << "\n";
    cout << string(80, '-') << "\n";

    // ── Initial state ─────────────────────────
    cout << setw(6)  << step++
         << setw(25) << "$"
         << setw(25) << inputToString(tokens, pos)
         << setw(25) << "Start"
         << "\n";

    // ─────────────────────────────────────────
    //  Main parsing loop:
    //  Keep going until input is exhausted AND
    //  the stack holds only the start symbol E.
    // ─────────────────────────────────────────
    while (true) {

        string action = "";

        // ── Try to REDUCE first ───────────────
        // We keep reducing as long as rules match
        // before shifting the next token.
        bool reduced = tryReduce(stk, action);

        if (reduced) {
            // Print the reduce step
            cout << setw(6)  << step++
                 << setw(25) << stackToString(stk)
                 << setw(25) << inputToString(tokens, pos)
                 << setw(25) << action
                 << "\n";
            continue;   // Try reducing again before shifting
        }

        // ── Check for ACCEPT condition ────────
        // Stack = just "E" and no more input
        if (pos == (int)tokens.size() &&
            !stk.empty() && stk.top() == "E") {

            // Make sure nothing is below E (stack should be exactly E)
            stack<string> check = stk;
            check.pop();   // remove E
            if (check.empty()) {
                cout << setw(6)  << step
                     << setw(25) << stackToString(stk)
                     << setw(25) << "$"
                     << setw(25) << "ACCEPT ✓"
                     << "\n";
                cout << string(80, '-') << "\n";
                cout << "\n✅  Input string is ACCEPTED by the grammar.\n\n";
                return;
            }
        }

        // ── SHIFT next token ──────────────────
        if (pos < (int)tokens.size()) {
            string token = tokens[pos++];
            stk.push(token);
            action = "SHIFT   " + token;

            cout << setw(6)  << step++
                 << setw(25) << stackToString(stk)
                 << setw(25) << inputToString(tokens, pos)
                 << setw(25) << action
                 << "\n";
        }
        else {
            // Input exhausted but stack is not the start symbol → REJECT
            cout << setw(6)  << step
                 << setw(25) << stackToString(stk)
                 << setw(25) << "$"
                 << setw(25) << "REJECT ✗"
                 << "\n";
            cout << string(80, '-') << "\n";
            cout << "\n❌  Input string is REJECTED.\n\n";
            return;
        }
    }
}

// ─────────────────────────────────────────────
//  Tokenizer
//  Splits raw input string into tokens.
//  Recognizes: "id", "+", "*"
// ─────────────────────────────────────────────
vector<string> tokenize(const string& input) {
    vector<string> tokens;
    int i = 0;

    while (i < (int)input.size()) {

        // Skip whitespace
        if (input[i] == ' ') { i++; continue; }

        // Multi-character token: "id"
        if (i + 1 < (int)input.size() &&
            input[i] == 'i' && input[i+1] == 'd') {
            tokens.push_back("id");
            i += 2;
        }
        // Single-character operators
        else if (input[i] == '+' || input[i] == '*') {
            tokens.push_back(string(1, input[i]));
            i++;
        }
        else {
            // Unknown character — skip with a warning
            cout << "Warning: Unknown character '" << input[i] << "' ignored.\n";
            i++;
        }
    }
    return tokens;
}

// ─────────────────────────────────────────────
//  Entry point
// ─────────────────────────────────────────────
int main() {

    cout << "============================================\n";
    cout << "   Shift Reduce Parser — Lab 09\n";
    cout << "   Compiler Construction\n";
    cout << "============================================\n";

    cout << "\nGrammar Rules:\n";
    cout << "  E → E + E\n";
    cout << "  E → E * E\n";
    cout << "  E → id\n";

    // ── The required input from the lab manual ──
    string inputString = "id + id * id";

    cout << "\nInput String: " << inputString << "\n";

    // Tokenize the input into individual symbols
    vector<string> tokens = tokenize(inputString);

    // Run the Shift Reduce Parser
    shiftReduceParser(tokens);

    return 0;
}
