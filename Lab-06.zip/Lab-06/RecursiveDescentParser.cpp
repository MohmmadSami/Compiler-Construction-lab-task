#include <iostream>
#include <string>

using namespace std;

// ---------------- GLOBAL VARIABLES ----------------

// Input string from user
string input;

// Current reading position in the input string
int pos_index = 0;

// ---------------- FUNCTION DECLARATIONS ----------------
void Stmtseq();
void Stmt();
void Exp();
bool match(const string& expected);
void require(const string& expected);

// -------------------------------------------------------
// match()
// Checks if the next part of input matches 'expected'.
// If it does, moves the pos_index forward.
// -------------------------------------------------------
bool match(const string& expected) {
    if (input.substr(pos_index, expected.length()) == expected) {
        pos_index += expected.length();
        return true;
    }
    return false;
}

// -------------------------------------------------------
// require()
// Forces a match. If 'expected' is not found, 
// prints an error and terminates the program.
// -------------------------------------------------------
void require(const string& expected) {
    if (!match(expected)) {
        cout << "\nParsing Error: Expected '" << expected << "' at position " << pos_index << "\n";
        cout << "String Rejected\n";
        exit(1);
    }
}

// -------------------------------------------------------
// Stmtseq → Stmt { ; Stmt }
// Parses a sequence of one or more statements.
// -------------------------------------------------------
void Stmtseq() {
    cout << "Parsing Stmtseq -> Stmt {; Stmt}" << endl;
    
    // Check if the current token starts a statement (starts with 'if')
    if (input.substr(pos_index, 2) == "if") {
        Stmt();
        
        // Handle repeated statements separated by semicolons
        while (input.substr(pos_index, 1) == ";") {
            match(";");
            Stmt();
        }
    }
}

// -------------------------------------------------------
// Stmt → if Exp then Stmtseq [else Stmtseq] end
// Parses the structure of a conditional statement.
// -------------------------------------------------------
void Stmt() {
    cout << "Parsing Stmt -> if Exp then Stmtseq [else Stmtseq] end" << endl;
    
    require("if");
    Exp();
    require("then");
    
    Stmtseq();
    
    // Check for optional 'else' block
    if (input.substr(pos_index, 4) == "else") {
        cout << "Found else, parsing else Stmtseq" << endl;
        require("else");
        Stmtseq();
    }
    
    require("end");
    cout << "End of Stmt" << endl;
}

// -------------------------------------------------------
// Exp → 0 | 1
// Parses a basic boolean expression (binary constant).
// -------------------------------------------------------
void Exp() {
    if (match("0")) {
        cout << "Parsing Exp -> 0" << endl;
    } else if (match("1")) {
        cout << "Parsing Exp -> 1" << endl;
    } else {
        cout << "\nParsing Error: Expected '0' or '1' at position " << pos_index << "\n";
        cout << "String Rejected\n";
        exit(1);
    }
}

// -------------------------------------------------------
// MAIN FUNCTION
// Entry point for the recursive descent parser.
// -------------------------------------------------------
int main() {
    cout << "Enter input program: ";
    cin >> input; // Reads input (no spaces allowed)
    
    pos_index = 0;
    
    // Begin parsing from the top-level grammar rule
    Stmtseq();
    
    // Check if the entire string was consumed according to rules
    if (pos_index == input.length()) {
        cout << "Parsing Successful: Input Accepted!" << endl;
    } else {
        cout << "\nString Rejected: Unexpected trailing characters\n";
    }
    
    return 0;
}