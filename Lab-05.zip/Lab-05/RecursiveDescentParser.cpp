#include <iostream>
#include <cstring>
#include <cctype>
using namespace std;

char input[200];
int pos = 0;
char token;
bool errorFlag = false;

/* Move to next character */
char advance() {
    return input[pos++];
}

/* Match expected symbol */
void match(char expected) {
    if (token == expected)
        token = advance();
    else
        errorFlag = true;
}

/* E → T E' */
void E();

/* E' → + T E' | - T E' | null */
void Eprime();

/* T → F T' */
void T();

/* T' → * F T' | / F T' | null */
void Tprime();

/* F → id | num | (E) */
void F();

/* Definition of functions */

void E() {
    cout << "E -> T E'\n";
    T();
    Eprime();
}

void Eprime() {
    if (token == '+') {
        cout << "E' -> + T E'\n";
        match('+');
        T();
        Eprime();
    }
    else if (token == '-') {
        cout << "E' -> - T E'\n";
        match('-');
        T();
        Eprime();
    }
    else {
        cout << "E' -> null\n";
    }
}

void T() {
    cout << "T -> F T'\n";
    F();
    Tprime();
}

void Tprime() {
    if (token == '*') {
        cout << "T' -> * F T'\n";
        match('*');
        F();
        Tprime();
    }
    else if (token == '/') {
        cout << "T' -> / F T'\n";
        match('/');
        F();
        Tprime();
    }
    else {
        cout << "T' -> null\n";
    }
}

void F() {
    if (isalpha(token)) {              // single letter id
        cout << "F -> id (" << token << ")\n";
        token = advance();
    }
    else if (isdigit(token)) {         // single digit num
        cout << "F -> num (" << token << ")\n";
        token = advance();
    }
    else if (token == '(') {           // (E)
        cout << "F -> (E)\n";
        match('(');
        E();
        if (token == ')')
            match(')');
        else
            errorFlag = true;
    }
    else {
        errorFlag = true;              // invalid token
    }
}

int main() {
    cout << "Enter expression: ";
    cin.getline(input, 200);

    /* Remove spaces */
    char temp[200];
    int j = 0;
    for (int i = 0; input[i] != '\0'; i++)
        if (input[i] != ' ')
            temp[j++] = input[i];

    temp[j++] = '$';     // end marker
    temp[j] = '\0';
    strcpy(input, temp);

    token = advance();   // get first token
    E();                 // start parsing from E

    if (!errorFlag && token == '$')
        cout << "Accepted\n";
    else
        cout << "Rejected\n";

    return 0;
}