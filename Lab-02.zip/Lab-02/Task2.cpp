#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("Task-02.txt");
    ofstream fout("Output.txt");

    char ch;
    bool inComment = false;

    cout << "Output:\n";

    while (fin.get(ch)) {
        if (ch == '{') {
            inComment = true;
        }
        else if (ch == '}') {
            inComment = false;
        }
        else if (!inComment) {
            fout << ch;   // write to file
            cout << ch;   // print on terminal
        }
    }

    cout << endl;

    fin.close();
    fout.close();

    return 0;
}
