#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("Task-01.txt");
    ofstream fout("Output.txt");

    char ch;

    cout << "Output:\n";

    while (fin.get(ch)) {
        if (ch != ' ' && ch != '\n' && ch != '\t') {
            fout << ch;     // write to file
            cout << ch;     // print on terminal
        }
    }

    cout << endl;

    fin.close();
    fout.close();

    return 0;
}
