#include <iostream>
#include <fstream>
using namespace std;

int main() {
    ifstream fin("Task-03.txt");
    ofstream fout("Output.txt");

    if (!fin.is_open()) {
        cout << "Error: Cannot open Task-03.txt\n";
        return 1;
    }

    char ch;
    bool inComment = false;

    cout << "Output:\n";

    while (fin.get(ch)) {
        if (ch == '{') {
            inComment = true;       // start comment
        }
        else if (ch == '}') {
            inComment = false;      // end comment
        }
        else if (!inComment) {
            if (ch != ' ' && ch != '\n' && ch != '\t') {
                fout << ch;         // write to Output.txt
                cout << ch;         // print on terminal
            }
        }
    }

    cout << endl;

    fin.close();
    fout.close();

    return 0;
}
